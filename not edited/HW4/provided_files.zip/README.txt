HOMEWORK 4: VISUAL DIFFERENCE LISTS


NAME:  < insert name >


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

< insert collaborators / resources >

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  < insert # hours >



ORDER NOTATION:
Give the order notation for each function below assuming
  w words in the first input file, and requiring
  i inserts, e erases, and r replace operations.
Write one or two sentences justifying each answer.


compute_diff - (default, non-optimal, non-recursive version)

apply_diff

invert_diff

assert_same

assert_same_diff

read_text

write_text

read_diff

write_diff

render_diff


OPTIONAL EXTRA CREDIT - RECURSIVE SOLUTION FOR MINIMUM EDIT DISTANCE:

Include running times and interesting screenshots of the HTML
visualization for test cases you created to debug your solution.

What is the big notation of your function? (Use the same variables as
above)


compute_diff - (optimal, ecursive version)



MISC. COMMENTS TO GRADER:  
Optional, please be concise!
