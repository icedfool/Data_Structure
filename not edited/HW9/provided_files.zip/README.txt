HOMEWORK 9: CONSTELLATION HASH TABLES


NAME:  < insert name >


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

< insert collaborators / resources >

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  < insert # hours >



PROGRAM DESIGN, DATA STRUCTURE & ALGORITHMS CHOICES:
Describe your overall algorithm design and how your choice of
algorithm / data structures evolved as you worked on this program.



CORRECTNESS & PERFORMANCE ANALYSIS:
Summarize the performance of your implementation on a variety of
different input files and command line arguments.  Document the
running time (use the UNIX 'time' command) of your program.



EXTRA CREDIT: HANDLING IMAGE SCALING
Describe your implementation and testing results.



MISC. COMMENTS TO GRADER:  
(optional, please be concise!)


