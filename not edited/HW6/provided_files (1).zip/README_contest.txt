HOMEWORK 6: CARCASSONNE CONTEST


NAME:  < insert name >



COLLABORATORS AND OTHER RESOURCES:
< insert collaborators / resources >



DESCRIPTION OF ANY PERFORMANCE IMPROVEMENTS/OPTIMIZATIONS:
(please be concise!)



DESCRIBE INTERESTING NEW PUZZLES YOU CREATED:



SUMMARY OF YOUR PERFORMANCE ON ALL PUZZLES:
Correctness & approximate wall clock running time for various command
line arguments.

